import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../../../prisma/prisma.service';
import { CreateFoodMessDto, UpdateFoodMessDto, FoodMessQueryDto } from '../dto';
import { PaginatedResponseDto } from '../../../common/dto';

@Injectable()
export class FoodService {
  constructor(private readonly prisma: PrismaService) {}

  async create(dto: CreateFoodMessDto) {
    const data: any = { ...dto };
    if (!data.totalCost && data.headCount && data.costPerHead) {
      data.totalCost = data.headCount * data.costPerHead;
    }
    return this.prisma.foodMess.create({ data });
  }

  async findAll(query: FoodMessQueryDto) {
    const { page = 1, limit = 20, search, sortBy = 'date', sortOrder = 'desc', mealType, date, site } = query;
    const where: any = {};

    if (search) {
      where.OR = [
        { menuItems: { contains: search, mode: 'insensitive' } },
        { remarks: { contains: search, mode: 'insensitive' } },
      ];
    }
    if (mealType) where.mealType = mealType;
    if (date) where.date = new Date(date);
    if (site) where.site = { contains: site, mode: 'insensitive' };

    const [data, total] = await Promise.all([
      this.prisma.foodMess.findMany({
        where,
        take: limit,
        skip: (page - 1) * limit,
        orderBy: { [sortBy]: sortOrder.toLowerCase() as any },
      }),
      this.prisma.foodMess.count({ where }),
    ]);

    return new PaginatedResponseDto(data as any, total, page, limit);
  }

  async getStats() {
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const [todayCount, todayCostSum, ratings, totalCostSum] = await Promise.all([
      this.prisma.foodMess.aggregate({
        where: { date: today },
        _sum: { headCount: true, totalCost: true },
      }),
      this.prisma.foodMess.aggregate({
        where: { date: today },
        _sum: { totalCost: true },
      }),
      this.prisma.foodMess.aggregate({
        where: { NOT: { rating: null } },
        _avg: { rating: true },
      }),
      this.prisma.foodMess.aggregate({
        _sum: { totalCost: true },
      }),
    ]);

    return {
      mealsToday: todayCount._sum.headCount || 0,
      avgRating: Math.round((Number(ratings._avg.rating) || 0) * 10) / 10,
      todayCost: Number(todayCount._sum.totalCost || 0),
      monthlyCost: Number(totalCostSum._sum.totalCost || 0),
    };
  }

  async findOne(id: string) {
    const f = await this.prisma.foodMess.findUnique({ where: { id } });
    if (!f) throw new NotFoundException(`Meal entry "${id}" not found`);
    return f;
  }

  async update(id: string, dto: UpdateFoodMessDto) {
    const f = await this.findOne(id);
    const data: any = { ...dto };
    
    const headCount = dto.headCount ?? f.headCount;
    const costPerHead = dto.costPerHead ?? Number(f.costPerHead);
    
    if (!dto.totalCost && headCount && costPerHead) {
      data.totalCost = headCount * costPerHead;
    }

    return this.prisma.foodMess.update({
      where: { id },
      data,
    });
  }

  async remove(id: string) {
    await this.findOne(id);
    await this.prisma.foodMess.delete({ where: { id } });
    return { message: 'Meal entry deleted' };
  }
}
