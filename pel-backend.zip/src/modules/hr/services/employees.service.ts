import { Injectable, NotFoundException, ConflictException } from '@nestjs/common';
import { PrismaService } from '../../../prisma/prisma.service';
import { CreateEmployeeDto, UpdateEmployeeDto, EmployeeQueryDto } from '../dto';
import { PaginatedResponseDto } from '../../../common/dto';

@Injectable()
export class EmployeesService {
  constructor(private readonly prisma: PrismaService) {}

  async create(dto: CreateEmployeeDto) {
    if (dto.cnic) {
      const existing = await this.prisma.employee.findUnique({ where: { cnic: dto.cnic } });
      if (existing) throw new ConflictException(`Employee with CNIC "${dto.cnic}" already exists`);
    }
    return this.prisma.employee.create({ data: dto as any });
  }

  async findAll(query: EmployeeQueryDto) {
    const { page = 1, limit = 20, search, sortBy = 'createdAt', sortOrder = 'desc', department, status } = query;
    
    const where: any = {};
    if (search) {
      where.OR = [
        { fullName: { contains: search, mode: 'insensitive' } },
        { cnic: { contains: search, mode: 'insensitive' } },
        { phone: { contains: search, mode: 'insensitive' } },
        { designation: { contains: search, mode: 'insensitive' } },
      ];
    }
    if (department) where.department = department;
    if (status) where.status = status;

    const allowed = ['createdAt', 'fullName', 'department', 'designation', 'basicSalary', 'joiningDate'];
    const col = allowed.includes(sortBy) ? sortBy : 'createdAt';

    const [data, total] = await Promise.all([
      this.prisma.employee.findMany({
        where,
        take: limit,
        skip: (page - 1) * limit,
        orderBy: { [col]: sortOrder.toLowerCase() },
      }),
      this.prisma.employee.count({ where }),
    ]);

    return new PaginatedResponseDto(data as any, total, page, limit);
  }

  async findOne(id: string) {
    const e = await this.prisma.employee.findUnique({ 
      where: { id }, 
      include: { attendanceRecords: true } 
    });
    if (!e) throw new NotFoundException(`Employee "${id}" not found`);
    return e;
  }

  async getStats() {
    const [totalEmployees, depts, statuses, salary] = await Promise.all([
      this.prisma.employee.count(),
      this.prisma.employee.groupBy({ by: ['department'], _count: { _all: true } }),
      this.prisma.employee.groupBy({ by: ['status'], _count: { _all: true } }),
      this.prisma.employee.aggregate({ _sum: { basicSalary: true } }),
    ]);

    const byDepartment: Record<string, number> = {};
    depts.forEach(d => byDepartment[d.department] = d._count._all);

    const byStatus: Record<string, number> = {};
    statuses.forEach(s => byStatus[s.status] = s._count._all);

    return { 
      totalEmployees, 
      byDepartment, 
      byStatus, 
      totalSalary: Number(salary._sum.basicSalary || 0) 
    };
  }

  async update(id: string, dto: UpdateEmployeeDto) {
    await this.findOne(id);
    return this.prisma.employee.update({
      where: { id },
      data: dto as any,
    });
  }

  async remove(id: string) {
    const emp = await this.findOne(id);
    await this.prisma.employee.delete({ where: { id } });
    return { message: `Employee "${emp.fullName}" deleted` };
  }
}
