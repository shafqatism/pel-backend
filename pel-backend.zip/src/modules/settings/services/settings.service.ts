import { Injectable, OnModuleInit } from '@nestjs/common';
import { PrismaService } from '../../../prisma/prisma.service';
import { UpdateSettingsDto } from '../dto/update-settings.dto';

@Injectable()
export class SettingsService implements OnModuleInit {
  constructor(private readonly prisma: PrismaService) {}

  async onModuleInit() {
    const count = await this.prisma.settings.count();
    if (count === 0) {
      await this.prisma.settings.create({
        data: {
          companyName: 'Petroleum Exploration Limited',
          currency: 'PKR',
          unitSystem: 'metric',
          maintenanceIntervalKm: 5000,
          systemEmail: 'admin@pelexploration.com.pk',
          brandingColors: {
            primary: '#d97706',
            secondary: '#1f2937',
            accent: '#fbbf24',
          },
          enableNotifications: true,
        },
      });
    }
  }

  async getSettings() {
    const settings = await this.prisma.settings.findMany();
    return settings[0];
  }

  async updateSettings(dto: UpdateSettingsDto) {
    const settings = await this.getSettings();
    return this.prisma.settings.update({
      where: { id: settings.id },
      data: dto as any,
    });
  }
}
