import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../../../prisma/prisma.service';
import { CreateTripDto, UpdateTripDto, TripQueryDto } from '../dto';
import { PaginatedResponseDto } from '../../../common/dto';

@Injectable()
export class TripsService {
  constructor(private readonly prisma: PrismaService) {}

  async create(dto: CreateTripDto) {
    return this.prisma.trip.create({ data: dto as any });
  }

  async findAll(query: TripQueryDto) {
    const { page = 1, limit = 20, search, sortBy = 'createdAt', sortOrder = 'desc', vehicleId, status } = query;
    const where: any = {};

    if (search) {
      where.OR = [
        { destination: { contains: search, mode: 'insensitive' } },
        { driverName: { contains: search, mode: 'insensitive' } },
        { purposeOfVisit: { contains: search, mode: 'insensitive' } },
      ];
    }
    if (vehicleId) where.vehicleId = vehicleId;
    if (status) where.status = status;

    const [data, total] = await Promise.all([
      this.prisma.trip.findMany({
        where,
        take: limit,
        skip: (page - 1) * limit,
        include: { vehicle: true },
        orderBy: { [sortBy]: sortOrder.toLowerCase() },
      }),
      this.prisma.trip.count({ where }),
    ]);

    return new PaginatedResponseDto(data as any, total, page, limit);
  }

  async findOne(id: string) {
    const t = await this.prisma.trip.findUnique({ where: { id }, include: { vehicle: true } });
    if (!t) throw new NotFoundException(`Trip "${id}" not found`);
    return t;
  }

  async update(id: string, dto: UpdateTripDto) {
    const trip = await this.findOne(id);
    const updateData: any = { ...dto };
    
    if (dto.meterIn && trip.meterOut) {
      updateData.totalKm = Number(dto.meterIn) - Number(trip.meterOut);
    }

    return this.prisma.trip.update({
      where: { id },
      data: updateData,
    });
  }

  async remove(id: string) {
    await this.findOne(id);
    await this.prisma.trip.delete({ where: { id } });
    return { message: 'Trip deleted' };
  }
}
