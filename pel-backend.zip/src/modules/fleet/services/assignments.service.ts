import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../../../prisma/prisma.service';
import { CreateAssignmentDto, UpdateAssignmentDto } from '../dto';
import { PaginatedResponseDto, PaginationQueryDto } from '../../../common/dto';

@Injectable()
export class AssignmentsService {
  constructor(private readonly prisma: PrismaService) {}

  async create(dto: CreateAssignmentDto) {
    return this.prisma.vehicleAssignment.create({ data: dto as any });
  }

  async findAll(query: PaginationQueryDto) {
    const { page = 1, limit = 20, search, sortOrder = 'desc' } = query;
    const where: any = {};

    if (search) {
      where.OR = [
        { assignedTo: { contains: search, mode: 'insensitive' } },
        { assignedBy: { contains: search, mode: 'insensitive' } },
        { purpose: { contains: search, mode: 'insensitive' } },
      ];
    }

    const [data, total] = await Promise.all([
      this.prisma.vehicleAssignment.findMany({
        where,
        take: limit,
        skip: (page - 1) * limit,
        include: { vehicle: true },
        orderBy: { createdAt: sortOrder.toLowerCase() as any },
      }),
      this.prisma.vehicleAssignment.count({ where }),
    ]);

    return new PaginatedResponseDto(data as any, total, page, limit);
  }

  async update(id: string, dto: UpdateAssignmentDto) {
    try {
      return await this.prisma.vehicleAssignment.update({
        where: { id },
        data: dto as any,
      });
    } catch (e) {
      throw new NotFoundException(`Assignment "${id}" not found`);
    }
  }

  async remove(id: string) {
    try {
      await this.prisma.vehicleAssignment.delete({ where: { id } });
      return { message: 'Assignment deleted' };
    } catch (e) {
      throw new NotFoundException(`Assignment "${id}" not found`);
    }
  }
}
