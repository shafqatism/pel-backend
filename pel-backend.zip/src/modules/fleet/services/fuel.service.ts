import { Injectable } from '@nestjs/common';
import { PrismaService } from '../../../prisma/prisma.service';
import { CreateFuelLogDto, FuelQueryDto } from '../dto';
import { PaginatedResponseDto } from '../../../common/dto';

@Injectable()
export class FuelService {
  constructor(private readonly prisma: PrismaService) {}

  async create(dto: CreateFuelLogDto) {
    return this.prisma.fuelLog.create({ data: dto as any });
  }

  async findAll(query: FuelQueryDto) {
    const { page = 1, limit = 20, search, sortBy = 'createdAt', sortOrder = 'desc', vehicleId } = query;
    const where: any = {};

    if (search) where.stationName = { contains: search, mode: 'insensitive' };
    if (vehicleId) where.vehicleId = vehicleId;

    const [data, total] = await Promise.all([
      this.prisma.fuelLog.findMany({
        where,
        take: limit,
        skip: (page - 1) * limit,
        include: { vehicle: true },
        orderBy: { [sortBy]: sortOrder.toLowerCase() },
      }),
      this.prisma.fuelLog.count({ where }),
    ]);

    return new PaginatedResponseDto(data as any, total, page, limit);
  }

  async getStats() {
    const result = await this.prisma.fuelLog.aggregate({
      _sum: {
        quantityLiters: true,
        totalCost: true,
      },
      _count: {
        id: true,
      },
    });

    return {
      totalLiters: Number(result._sum.quantityLiters || 0),
      totalCost: Number(result._sum.totalCost || 0),
      totalEntries: Number(result._count.id || 0),
    };
  }
}
