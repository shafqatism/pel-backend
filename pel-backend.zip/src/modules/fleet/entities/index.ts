export { Vehicle } from './vehicle.entity';
export { Trip } from './trip.entity';
export { FuelLog } from './fuel-log.entity';
export { MaintenanceRecord } from './maintenance-record.entity';
export { VehicleAssignment } from './vehicle-assignment.entity';
